
#include<stdio.h>

int g = 10 ; // global veri

namespace ns1
{
    int connector=3307;
    namespace nns
    {
        int value=101;
    }
}
namespace ns2
{
    int connector=9908;
    int n1=11;
    int n2=12;
    int n3=13;
    int n4=14;
    int n5=15;
    int n6=16;
}

int main()
{
    
    printf("\n global veri g=%d",g);
    printf("\n global veri :: g=%d",  ::g);

    printf("\n connector=%d", ns1::connector);
    printf("\n ns1::nns::value=%d",ns1::nns::value);

    printf("\n n1=%d",ns2::n1);
    //printf("\n n1=%d",n1);
    using namespace ns2;
    printf("\n n2=%d",ns2::n2);
    printf("\n n2=%d",n2);
    printf("\n");
    return 0;
}
