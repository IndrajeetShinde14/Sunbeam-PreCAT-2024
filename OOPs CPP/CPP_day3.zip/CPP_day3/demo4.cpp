#include<iostream>
using namespace std;

class complex
{
    int real;
    int imag;
    public:
    complex()
    {
        cout<<"\n ------complex()-------";
        this->real=1;
        this->imag=1;
    }	
    complex(int r,int i)
    {
        cout<<"\n ------complex(int ,int)-------";
        this->real=r;
        this->imag=i;
    }
	void acceptComplexNumber()
    {
        cout<<"\n Enter complex number";
        cin>>this->real>>this->imag;
    }
	void printComplexNumber()
    {
        cout<<"\n Complex Number="<<this->real<<"+j"<<this->imag;
    }
	~complex()
    {
        cout<<"\n ------ ~complex()-------";
    }
};


int main()
{
    complex c1;
    c1.acceptComplexNumber();
    c1.printComplexNumber();
    cout<<"\n";
    return 0;
}