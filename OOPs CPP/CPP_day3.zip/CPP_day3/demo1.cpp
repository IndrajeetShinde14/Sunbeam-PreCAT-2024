#include<stdio.h>
class time
{
    private:
        int hr;
        int min;
        int sec;
    public:
        // time() //Parameterless constructor 
        // {
        //         printf("\n ------- time()-------");
        //         this->hr=0;
        //         this->min=0;
        //         this->sec=0;
        // }
        time(int h=0,int m=0,int s=0) //Parameterized constructor
        {
            printf("\n ------- time(int,int,int)-------");
            hr=h;
            min=m;
            this->sec=s;
        }
        // t_p.setMin(15);
        void setMin(int min) //setter
        {   //6 = 24
            this->min=min;
        }
        //setHr()  home work
        //setSec()

        //int second=t_p.getSec();
        int getSec() //getter
        {
            return this->sec;
        }

        void initTime()
        {
            this->hr=0;
            this->min=0;
            this->sec=0;
        }
        void printTime() //Facilitator
        {
            printf("\n Time = %d : %d : %d",this->hr,this->min,this->sec);
        }
        void acceptTime( ) //Facilitator
        {
            printf("\n enter time");
            scanf("%d%d%d",&this->hr,&this->min,&this->sec);
        }
        void inchTimeByOneSec() //Facilitator
        {
            this->sec++;
            if(this->sec>=60)
            {
                this->sec=0;
                this->min++;
            }
            if(this->min>=60)
            {
                this->min=0;
                this->hr++;
            }
            if(this->hr>=24)
            {
                this->hr=0;
            }
        }
        ~time()
        {
            printf("\n -----  ~time() -----");
        }

};//end of class

int main()
{
    
    // time t1;
    // t1.printTime();

    // time t2;
    // t2.printTime();

    time t_p(9,30,44); //9:30:44
   // t_p.min=15;
    t_p.setMin(15);
    t_p.printTime();

    //int second=t_p.sec;
    int second=t_p.getSec();
    printf("\n second=%d",second);


    // time t_k(8,45,50); // 8:45:50;
    // t_k.printTime();
   

    


    return 0;
}