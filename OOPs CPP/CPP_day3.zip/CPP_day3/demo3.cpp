
#include<stdio.h>
#include<iostream>
using namespace std;

//printf() ->  cout  -> <<
//scanf()  ->  cin   -> >>


int main()
{

    printf("\n Hello all ..");
    cout<<"\n Hello all ..";

    int a=11;
    printf("\n value of a=%d",a);
    cout<<"\n value of a="<<a;

    int x=12,y=13;
    printf("\n value of x=%d , value of y=%d",x,y);
    cout<<"\n value of x="<<x<<" , value of y="<<y;

    int n;
    cout<<"\n enter value for n";
    //scanf("%d",&n);
    cin>>n;
    cout<<"\n value of n="<<n;


    int n1,n2;
    cout<<"\n enter value for n1,n2";
   // scanf("%d%d",&n1, &n2);
    cin>>n1>>n2;
    cout<<"\n value of n1="<<n1<<" , value of n2="<<n2;

    printf("\n");
    return 0;
}
