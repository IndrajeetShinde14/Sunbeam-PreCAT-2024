#include<iostream>
using namespace std;
class date
{
    private:
        int dd;
        int mm;
        int yy;
    public:
        date()
        {
            this->dd=1;
            this->mm=1;
            this->yy=2000;
            cout<<"inside parameterless ctor of date class"<<endl;
        }
        date(int dd, int mm, int yy)
        {
            this->dd=dd;
            this->mm=mm;
            this->yy=yy;
            cout<<"inside parameterized ctor of date class"<<endl;
        }
        void accept_input()
        {
            cout<<"Enter dd-mm-yyyy format=\n";
            cin>>this->dd;
            cin>>this->mm;
            cin>>this->yy;

        }
        void print_output()
        {
            cout<<"date="<<endl;
            cout<<this->dd<<"-"<<this->mm<<"-"<<this->yy<<endl;
        }

        date add_no_days(date d1, int no_of_days)
        {

        }

        bool is_valid_date()
        {                
            int months[]={31,28,31, 30, 31, 30 , 31, 31 ,30, 31, 30, 31};
            if( this->yy%4==0)  // if leap year feb 29 days
                months[2]=29;  
            if(!( this->yy>=100 && this->yy<=9999 ))
                return false;
            if(!( this->mm>=1 && this->mm<=12))
                return false;
            if( !(this->dd>=1 && this->dd<= months[this->mm-1]))
            return false;
         return true;
        }

        ~date()
        {
            this->dd=0;
            this->mm=0;
            this->yy=0;
            cout<<"inside dtor of date class"<<endl;
        }
};
int main(void)
{
    bool flag= true;
    date objDate1;

    do 
    {
        if( !flag)
            cout<<"invalid date::"<<endl;

        cout<<"objDate1=";
        objDate1.accept_input();
        flag=false;
     
    }while (!objDate1.is_valid_date() );
     objDate1.print_output();
    return 0;
}


// add no of days in a date
// 12-2-2000   date
//+30          no of days
// 42-29            13+12=
//===========
// 29-3-2000  new date   

// add no of days in a date
// 26-1-2024   date
//+50          no of days
// 16 march 2024
/*
    31-26= 5
    50-5=  45
    45-29=16

*/



// add no of days in a date
// 26-1-2024   date
//+76          no of days
// 12 apr 2024
/*
    31-26= 5
    76-5=  71
    71-29= 42
    42-31=12

*/
