//Pure virtual function and Abstract class

//class shape


#include<iostream>
using namespace std;


class shape //Abstract class
{
    public:
    virtual  void  calArea()=0; //Pure virtual function 
    virtual void input()=0; //Pure virtual function 
};

class square: public shape //Abstract class
{
    int s;
    
};
class rect : public shape
{
    int l , b;
    public:
    void  calArea()
    {
        int a=l*b;
        cout<<"\n Area of Rect="<<a;
    }
    void input()
    {
        cout<<"\n Enter l and b for rect";
        cin>>l>>b;
    }
};

class circle: public shape
{
    int r;
    public:
    void  calArea()
    {
        int a=3.14*r*r;
        cout<<"\n Area of circle="<<a;
    }
    void input()
    {
        cout<<"\n Enter r for circle";
        cin>>r;
    }
};
int main()
{
    // shape sp;
    // square sq1;

    shape *sptr=NULL;
    rect r1;
    circle c1;
    int ch;
    do
    {
       cout<<"\n enter 1:rect 2:circle 0:exit";
       cin>>ch;
       switch (ch)
       {
       case 1:
        sptr=&r1;
        break;
       case 2:
        sptr=&c1;
        break;
       }
        if(sptr!=NULL)
        {
            sptr->input();
            sptr->calArea();
        }
        sptr=NULL;
    } while (ch!=0);
    

    // shape s1;
    // s1.input();
    // s1.calArea();

    // rect r1;
    // r1.input();
    // r1.calArea();

    // circle c1;
    // c1.input();
    // c1.calArea();
    cout<<"\n";
    return 0;
}