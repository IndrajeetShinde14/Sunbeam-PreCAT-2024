#include<iostream>
using namespace std;

//base class
//parent class
class person
{
    protected:
        int age;
        string name;
    public:
    person()
    {
        age=24;
        name="Ravi";
    }
    void printPerson()
    {
        cout<<"\n Name="<<name<<" age="<<age;
    }
};
// derived class
// child class
// emp is-a person
class emp : public person
{
    int empid;
    int sal;
    public:
    emp()
    {
        empid=5;
        sal=20000;
    }
    void printEmp() //4
    {
        this->printPerson(); //2
        cout<<" empid="<<empid<<"  sal="<<sal;
    }
    void updateName(string newName)
    {
        this->name=newName; //valid
    }
};
int main()
{
    // person p1;
    // p1.printPerson();

    emp e1;
    e1.printEmp();
    //Ravi  ->  Ravee

    // e1.name="Ravee";  //invalid

    e1.updateName("Ravee");
    cout<<"\n";
    return 0;
}