#include<iostream>
using namespace std;

class constDemo
{
    private:
        int n;
        const int c; //Constant data member
        mutable int m;
    public:
        constDemo():c(20) //constructors member initializer list.
        {
            n=10;
           // c=20;
            m=30;
        }
        void printData() const //Const member function
        {
            //n++;
            //c++;
            m++; //mutable data members are allowed to modify in Const member function.
            cout<<"\n n="<<n;
            cout<<"\n c="<<c;
            cout<<"\n m="<<m;
        }
};
int main()
{
    constDemo d1;
    d1.printData();
    cout<<"\n";
    return 0;
}