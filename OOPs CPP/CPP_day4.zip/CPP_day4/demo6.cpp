#include<iostream>
using namespace std;
//int x=a (11)
//int y=b (99)

//int& refa=a
void  mySwap(int& refa,int& refb)
{
    int t=refa;
    refa=refb;
    refb=t;
}
int main()
{
    int a=11,b=99;
    cout<<"\n before swap a="<<a<<" b="<<b; //11 99
    mySwap(a,b);
    cout<<"\n after swap a="<<a<<" b="<<b;// 99 11
    cout<<"\n";
    return 0;
}