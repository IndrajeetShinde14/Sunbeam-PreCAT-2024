
#include"complex.h"
int main()
{
    complex c1;
    c1.show();
}

//g++ complex.cpp program.cpp