class complex 
{
    private:
		int real, imag;

	public: 
        complex();
		void show();
};
