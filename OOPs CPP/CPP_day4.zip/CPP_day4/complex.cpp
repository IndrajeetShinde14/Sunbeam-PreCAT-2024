
#include<iostream>
using namespace std;
#include"complex.h"
void complex::show()
{
    cout<<"\n Complex Number="<<this->real<<"+j"<<this->imag;
}
complex::complex()
{
	real = 5;
    imag = 7;
}
