#include<iostream>
using namespace std;


int main()
{
    int n; 
    n=10;

    int n1=11;

    const int c=111;
    //const int c;  error
   // c=22;        // error
    //c++;          error

    cout<<"\n";
    return 0;
}