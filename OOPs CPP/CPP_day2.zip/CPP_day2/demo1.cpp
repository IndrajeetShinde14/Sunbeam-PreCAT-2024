#include<stdio.h>
struct time
{
    private:
        int hr;
        int min;
        int sec;
    public:
        void printTime()
        {
            printf("\n Time = %d : %d : %d",hr,min,sec);
        }
        void acceptTime( )
        {
            printf("\n enter time");
            scanf("%d%d%d",&hr,&min,&sec);
        }
        void inchTimeByOneSec()
        {
            //home work
        }
};//end of struct
int main()
{
    int n1;
    time t1; //when time is struct then t1 is called as veriable
    t1.acceptTime();
    //t1.hr=8;
    t1.printTime();
    return 0;
}