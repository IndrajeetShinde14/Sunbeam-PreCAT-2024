#include<stdio.h>

class empty
{

};

int main()
{
    empty e1;
    printf("\n size of empty class obj e1=%d",sizeof(e1));
    empty e2;
    return 0;
}