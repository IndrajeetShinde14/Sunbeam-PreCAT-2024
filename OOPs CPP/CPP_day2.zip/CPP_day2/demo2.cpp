#include<stdio.h>
class time
{
    private:
        int hr;
        int min;
        int sec;
    public:
        void printTime()
        {
            printf("\n Time = %d : %d : %d",this->hr,this->min,this->sec);
        }
        void acceptTime( )
        {
            printf("\n enter time");
            scanf("%d%d%d",&this->hr,&this->min,&this->sec);
        }
        void inchTimeByOneSec()
        {
            //home work
        }
};//end of class

int main()
{
    int n1;
    time t1;//when time is a class then t1 is called as object
    printf("\n size of t1=%d",sizeof(t1)); //12 byte
    t1.acceptTime();
    t1.printTime();

    time t2;
    t2.acceptTime();
    t2.printTime();

    time t3;
    t3.acceptTime();
    t3.printTime();


    return 0;
}