#include<stdio.h>

//inline void printMessage();

//inline function ensures faster execution of function.

inline void printMessage()
{
    printf("\n Hello all ... :) ");
}

int main()
{
    printMessage();
    printMessage();
    printMessage();
    printMessage();
    return 0;
}



