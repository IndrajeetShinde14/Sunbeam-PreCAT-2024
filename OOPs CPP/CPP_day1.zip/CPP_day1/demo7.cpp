#include<stdio.h>
struct time
{
    int hr;
    int min;
    int sec;
    void printTime()
    {
        printf("\n Time = %d : %d : %d",hr,min,sec);
    }
    void acceptTime( )
    {
        printf("\n enter time");
        scanf("%d%d%d",&hr,&min,&sec);
    }
    void inchTimeByOneSec()
    {
        //home work
    }
};//end of struct
int main()
{
    int n1;
    time t1;
    //7:16:45
    t1.hr=7;
    t1.min=16;
    t1.sec=45;
    t1.printTime();
    t1.acceptTime();
    t1.printTime();
    return 0;
}