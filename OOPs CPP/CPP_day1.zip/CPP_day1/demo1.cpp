#include<stdio.h>

int main()
{
    printf("\n Hello everyone ... !!");
    return 0;
}

//g++ demo1.cpp
//./a.exe   