#include<stdio.h>
//
//bool :- it can take true or false value. It takes one byte in memory.
//wchar_t :- it can store 16 bit character. It takes 2 bytes in memory.
//

int main()
{

    bool b=false; //false
    printf("\n bool b=%d  size of b=%d", b,sizeof(b));

    wchar_t wch='A';
    printf("\n wchar_t wch=%c  size of wch=%d", wch,sizeof(wch));


    return 0;
}
