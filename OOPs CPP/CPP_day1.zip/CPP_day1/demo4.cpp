#include<stdio.h>
//Function Overloading

void printValue(int n)
{
    printf("\n value of int n=%d",n);
}
//Return type is not considered for function overloading.
// int printValue(int n)
// {
//     printf("\n value of int n=%d",n);
//     return 0;
// }

void printValue(char ch)
{
    printf("\n value of char ch=%c",ch);
}
void printValue(int n1,int n2)
{
    printf("\n value of int n1=%d, int n2=%d",n1,n2);
}
void printValue(int n1,char ch1)
{
    printf("\n value of int n1=%d , char ch1=%c",n1,ch1);
}
void printValue(char ch1,int n1)
{
    printf("\n value of char ch1=%c , int n1=%d ",ch1,n1);
}
int main()
{
    printValue(10);
    printValue('A');
    printValue(20,30);
    printValue(11,'N');
    printValue('S',99);
    return 0;
}