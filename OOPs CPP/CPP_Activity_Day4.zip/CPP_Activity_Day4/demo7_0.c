// run on online compiler by selecting turboc compiler
//https://www.onlinegdb.com/online_c_compiler     use this url
#include<stdio.h>
void pascal fun(int x,int y,int z)
{
    printf("%d %d %d",x,y,z);
}
int main()
{
    int a=3;
    //    4  5   6   print this
    //    3  4   5 
    fun(++a,++a,++a); // pascal left to right
    return 0;
}// output will be  4 5 6
