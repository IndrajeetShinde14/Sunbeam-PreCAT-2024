#include<iostream>
using namespace std;
class Point
{
    private:
        int xPosition;
        int yPosition;
    public:
   
       // parameterless ctor
        Point()
        {
            this->xPosition=10;
            this->yPosition=20;
            cout<<"parameterless ctor "<<endl;

        }
        // parameterized ctor with 1 arg
        Point(int value)
        {
            this->xPosition=value;
            this->yPosition=value;
            cout<<"parameterzied with 1 arg "<<endl;
        }
        // parameterized ctor with 2 arg
        Point(int xPosition, int yPosition)
        {
            this->xPosition=xPosition;
            this->yPosition=yPosition;
            cout<<"parameterzied with 2 arg "<<endl;
        }
    
    
    
        void print()
        {
            cout<<"this->xPosition="<<this->xPosition<<endl;
            cout<<"this->yPosition="<<this->yPosition<<endl;
        }
};

int main()
{
    Point p1();

    // it is a function decl so no ctor will be called

    return 0;
}