#include<iostream>
using namespace std;
class Point
{
    private:
        int xPosition;
        int yPosition;
    public:
        void print()
        {
            cout<<"this->xPosition="<<this->xPosition<<endl;
            cout<<"this->yPosition="<<this->yPosition<<endl;
        }
};
Point p2; // global
int main()
{
    Point p1; // local
    cout<<"p1="<<endl;
    p1.print(); // xPosition= garbage yPosition= garbage
    cout<<"p2="<<endl;
    p2.print(); // xPosition= 0 Position= 0

    static Point p3; // static
    cout<<"p3="<<endl;
    p3.print(); // xPosition= 0  yPosition= 0
    
    return 0;
}