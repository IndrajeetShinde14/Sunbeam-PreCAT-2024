#include<stdio.h>
int price=100;
int main(void)
{
    int price=10;
    printf("\n local price =%d", price);
    return 0;
}