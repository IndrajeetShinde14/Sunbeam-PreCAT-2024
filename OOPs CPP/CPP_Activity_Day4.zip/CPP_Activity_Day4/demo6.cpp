#include<iostream>
using namespace std;
class Point
{
    private:
        int xPosition;
        int yPosition;
    public:
    // parameterless ctor
        Point()
        {
            this->xPosition=10;
            this->yPosition=20;
        }
        // parameterized ctor with 1 arg
        Point(int value)
        {
            this->xPosition=value;
            this->yPosition=value;
        }
        // parameterized ctor with 2 arg
        Point(int xPosition, int yPosition)
        {
            this->xPosition=xPosition;
            this->yPosition=yPosition;
        }
    
        void print()
        {
            cout<<"this->xPosition="<<this->xPosition<<endl;
            cout<<"this->yPosition="<<this->yPosition<<endl;
        }
};

int main()
{
    Point p1; // parameterless ctor
    Point *ptrPoint=&p1;
    cout<<"p1="<<endl;
    p1.print(); // xPosition= 10 yPosition= 20
   // int                          Point pointer
    int *ptr= reinterpret_cast<int*>(ptrPoint);

    *ptr= 5;
     ptr=ptr+1;   
     *ptr=7;
     cout<<"p1="<<endl;
    p1.print(); // xPosition= 5 yPosition= 7
     

    
    return 0;
}