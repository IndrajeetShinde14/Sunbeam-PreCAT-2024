#include<iostream>
using namespace std;
int price=100;
int main(void)
{
    int price=10;
    cout<<"price local="<<price<<endl;
    cout<<"price globla="<<::price<<endl;
    return 0;
}