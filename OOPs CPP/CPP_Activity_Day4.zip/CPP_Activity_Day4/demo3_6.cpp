#include<iostream>
using namespace std;
class Point
{
    private:
        int xPosition;
        int yPosition;
    public:
   
       // parameterless ctor
        Point()
        {
            this->xPosition=10;
            this->yPosition=20;
            cout<<"parameterless ctor "<<endl;

        }
        // parameterized ctor with 1 arg
        Point(int value)
        {
            this->xPosition=value;
            this->yPosition=value;
            cout<<"parameterzied with 1 arg "<<endl;
        }
        // parameterized ctor with 2 arg
        Point(int xPosition, int yPosition)
        {
            this->xPosition=xPosition;
            this->yPosition=yPosition;
            cout<<"parameterzied with 2 arg "<<endl;
        }
    
        ~Point()
        {
            cout<<"==============="<<endl;
            this->print();
            cout<<"==============="<<endl;
            this->xPosition=0;
            this->yPosition=0;
            cout<<"dtor "<<endl;
        }
    
        void print()
        {
            cout<<"this->xPosition="<<this->xPosition<<endl;
            cout<<"this->yPosition="<<this->yPosition<<endl;
        }
};

int main()
{
    {
        Point(10,20).print();//parameterzied with 2 arg 
    }
    {
        Point(111).print();//parameterzied with 1 arg 
    }
    {
        Point().print();//parameterless ctor 
    }

 
    //Point p1(11).print(); //error
    return 0;
}