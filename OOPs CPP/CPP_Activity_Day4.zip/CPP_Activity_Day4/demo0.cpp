/*
static data member and function
diamond pro sol no2 diagram

ctor
namespace
reference
casting oeprator
*/