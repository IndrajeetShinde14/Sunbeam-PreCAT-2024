#include<iostream>
using namespace std;
class Point
{
    private:
        int xPosition;
        int yPosition;
    public:
   
        // parameterized ctor with default arg 
        Point(int xPosition=10, int yPosition=20)
        {
            this->xPosition=xPosition;
            this->yPosition=yPosition;
        }
    
        void print()
        {
            cout<<"this->xPosition="<<this->xPosition<<endl;
            cout<<"this->yPosition="<<this->yPosition<<endl;
        }
};

int main()
{
    Point p1; // parameterized ctor with default arg 

    cout<<"p1="<<endl;
    p1.print(); // xPosition= 10 yPosition= 20
    
    Point p2(111); // parameterized ctor with default arg 
    cout<<"p2="<<endl;
    p2.print(); // xPosition= 111 Position= 20

    Point p3(222,333); //parameterized ctor with default arg arg
    cout<<"p3="<<endl;
    p3.print(); // xPosition=222 Position=333

    
    return 0;
}