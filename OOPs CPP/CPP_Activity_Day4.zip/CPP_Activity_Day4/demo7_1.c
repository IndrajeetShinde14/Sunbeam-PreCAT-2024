// run on online compiler by selecting turboc compiler
//https://www.onlinegdb.com/online_c_compiler     use this url
#include<stdio.h>
void cdecl fun(int x,int y,int z)
{
    printf("%d %d %d",x,y,z);
}
int main()
{
    int a=3;
    //    6   5    4  
    //    5   4    3       
    fun(++a,++a,++a);  // cdecl right left
    return 0;
}// output will be  6 5 4

