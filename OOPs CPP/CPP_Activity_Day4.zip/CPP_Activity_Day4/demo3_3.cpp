#include<iostream>
using namespace std;
class Point
{
    private:
        int xPosition;
        int yPosition;
    public:
   
        // parameterized ctor with default arg 
        Point(int xPosition=10, int yPosition=20)
        {
            this->xPosition=xPosition;
            this->yPosition=yPosition;
            cout<<"parameterized ctor with default arg "<<endl;
        }
    
        void print()
        {
            cout<<"this->xPosition="<<this->xPosition<<endl;
            cout<<"this->yPosition="<<this->yPosition<<endl;
        }
};

int main()
{
    Point p1(111,222); // parameterized ctor with default arg 

    Point &p2=p1;  // p2 is ref for p1

    Point *ptr1=&p1;  // ptr1 is pointer
 
    
    return 0;
}