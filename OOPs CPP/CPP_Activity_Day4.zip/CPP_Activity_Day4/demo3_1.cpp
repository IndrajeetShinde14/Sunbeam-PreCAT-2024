#include<iostream>
using namespace std;
class Point
{
    private:
        int xPosition;
        int yPosition;
    public:
    // parameterless ctor
        Point()
        {
            this->xPosition=10;
            this->yPosition=20;
        }
        // parameterized ctor with 1 arg
        Point(int value)
        {
            this->xPosition=value;
            this->yPosition=value;
        }
        // parameterized ctor with 2 arg
        Point(int xPosition, int yPosition)
        {
            this->xPosition=xPosition;
            this->yPosition=yPosition;
        }
    
        void print()
        {
            cout<<"this->xPosition="<<this->xPosition<<endl;
            cout<<"this->yPosition="<<this->yPosition<<endl;
        }
};

int main()
{
    Point p1; // parameterless ctor
    cout<<"p1="<<endl;
    p1.print(); // xPosition= 10 yPosition= 20
    
    Point p2(111); // parameterized ctor with 1 arg
    cout<<"p2="<<endl;
    p2.print(); // xPosition= 111 Position= 111

    Point p3(222,333); // parameterized ctor with 2 arg
    cout<<"p3="<<endl;
    p3.print(); // xPosition=222 Position=333

    
    return 0;
}