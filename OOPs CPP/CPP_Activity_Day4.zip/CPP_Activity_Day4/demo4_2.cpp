#include<iostream>
using namespace std;
namespace s_seller
{
    int price=90; // s_seller::price=90
    namespace b_seller
    {
        int price=70; // b_seller::price=70
    }
}
int price=100;
int main(void)
{
    int price=10;
    cout<<"price local="<<price<<endl; // 10
    cout<<"price global="<<::price<<endl; // 100
    cout<<"s_seller::price="<<s_seller::price<<endl; // 90
    cout<<"s_seller::price="<<s_seller::b_seller::price<<endl; //70
    using namespace s_seller;
    cout<<"price ="<<price<<endl; // 10 local
    cout<<"s_seller::price="<<s_seller::price<<endl; // 90

    using namespace s_seller::b_seller;
    // or
    //using namespace b_seller;
    cout<<"price ="<<price<<endl; // 10 local
    cout<<"s_seller::price="<<s_seller::b_seller::price<<endl; //70

    return 0;
}