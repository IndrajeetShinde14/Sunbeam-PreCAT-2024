#include<iostream>
using namespace std;
class StaticDemo
{
    private:
        // non static data member        
        int id;
        int a;
        int b;
        // static data member        
        static int counter;
    public:
        StaticDemo()
        {
            this->a=10;
            this->b=20;
            StaticDemo::counter++;
            StaticDemo::id= StaticDemo::counter;
        }
        StaticDemo(int a, int b)
        {
            this->a=a;
            this->b=b;
            StaticDemo::counter++;
            StaticDemo::id= StaticDemo::counter;
        }
        // non static member fun
        void print()
        {
            cout<<"this->id="<< this->id <<"\t["<<&this->id<<"]"<<endl;
            cout<<"(*this).id="<< (*this).id <<"\t["<<&(*this).id<<"]"<<endl;
            cout<<"this->a="<<this->a <<"\t["<<&this->a<<"]"<<endl;
            cout<<"this->b="<<this->b <<"\t["<<&this->b<<"]"<<endl;
            cout<<"StaticDemo::counter="<< StaticDemo::counter <<"\t["<<&StaticDemo::counter<<"]"<<endl;
        }
        // static member fun
        static void set_counter(int counter)
        {
                StaticDemo::counter= counter;
                //this->a=counter; error
                //b=counter; //erorr
        }
        ~StaticDemo()
        {
            this->a=0;
            this->b=0;            
            StaticDemo::id=0;
        }

};
int StaticDemo::counter=1000;
//Data_type class_Name::static_Data_member=value; 
int main(void)
{
    StaticDemo::set_counter(500);
    StaticDemo s1(10,20);
    cout<<"s1="<<endl;
    s1.print();
    cout<<"size of s1="<<sizeof(s1)<<endl; // 4(a)+ 4(b) + 4(id)= 12 bytes

    StaticDemo s2(30,40);
    cout<<"s2="<<endl;
    s2.print(); //a= 
    cout<<"size of s2="<<sizeof(s2)<<endl; // 4(a)+ 4(b) + 4(id)= 12 bytes

    StaticDemo s3(50,60), s4(70, 80);
    cout<<"s3="<<endl;
    s3.print(); // id=503 a=30 b=40 counter= 504  
    cout<<"size of s1="<<sizeof(s1)<<endl; 
    cout<<"s4="<<endl;    
    s4.print(); // id=504 a=70 b=80 counter=504
    cout<<"size of s4="<<sizeof(s4)<<endl; 
    return 0;
}