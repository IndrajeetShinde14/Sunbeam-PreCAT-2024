#include<iostream>
using namespace std;
void swap(int &n1, int &n2)
{
    int temp;
    temp=n1;
    n1=n2;
    n2=temp;
}
int main(void)
{
    int no1=10, no2=20;
    swap(no1,no2); 
    cout<<"after swap no1="<<no1<<" \n no2="<<no2<<endl;
} // after swap no1=20  no2=10