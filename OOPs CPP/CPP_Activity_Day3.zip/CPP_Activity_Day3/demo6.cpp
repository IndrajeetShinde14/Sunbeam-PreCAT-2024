// try catch and throw
#include<iostream>
using namespace std;
int main(void)
{
    #line 1000
    int no1, no2, ans;

    try 
    {   
        cout<<"Enter no1=";
        cin>>no1;

        cout<<"Enter no2=";
        cin>>no2;

        if(no2==0)
            // throw 1.4;  // double
            // throw 'a';   // char
             throw __LINE__+ 1;  // int    
            ans= no1/no2;
        cout<<"ans="<<ans;
    }
    catch(int no)
    {
        cout<<"inside int1 catch"<<endl;
        cout<<"can not divide by zero"<<endl;
        cout<<"error at line no="<<no<<endl;
        cout<<"error in file="<<__FILE__<<endl;
        cout<<"Date="<<__DATE__<<endl;
        cout<<"Time="<<__TIME__<<endl;
    }
    catch(int)
    {
        cout<<"inside int2 catch"<<endl;
        cout<<"can not divide by zero"<<endl;
    }
    catch(float)
    {
        cout<<"inside float catch"<<endl;
        cout<<"can not divide by zero"<<endl;
    }
    catch(double)
    {
        cout<<"inside double catch"<<endl;
        cout<<"can not divide by zero"<<endl;
    }
    catch(...) // ellipse
    {
        cout<<"inside generic catch"<<endl;
        cout<<"can not divide by zero"<<endl;
    }


    return 0;
}