// stl -- std template lib
#include<iostream>
using namespace std;
namespace NSWAP
{
    void  swap(int &n1, int &n2)
    {
        cout<<"inside my swap func"<<endl;
        int temp;
        temp=n1;
        n1=n2;
        n2=temp;
    }
}
int main(void)
{
    int no1=100, no2=200;
    cout<<"before swap in main no1="<<no1<<" \t no2="<<no2<<endl;
    NSWAP::swap(no1, no2); // my swap
    cout<<"after swap in main no1="<<no1<<" \t no2="<<no2<<endl;

    cout<<"============================="<<endl;
    
    float n1=2.3f, n2=3.2f;
    cout<<"before swap in main n1="<<n1<<" \t n2="<<n2<<endl;
    swap(n1, n2);  // stl swap
    cout<<"after swap in main n1="<<n1<<" \t n2="<<n2<<endl;

    return 0;
}

