#include<iostream>
using namespace std;
namespace NCasting
{
    class Base
    {
        private:
            int a; 
            int b;
        public:
            Base()
            {
                this->a=0;
                this->b=0;
                cout<<"parameterless ctor of base class"<<endl;
            }
            Base(int a, int b)
            {
                this->a=a;
                this->b=b;
                cout<<"parameterized ctor of base class"<<endl;
            }
            //void print()
            virtual void print()
            {
                cout<<"inside class Base"<<endl;
                cout<<"this->a="<<this->a<<"["<< &this->a<<"]"<<endl;
                cout<<"this->b="<<this->b<<"["<< &this->b<<"]"<<endl;
            }

            ~Base()
            {
                this->a=0;
                this->b=0;
                cout<<"dtor of base class"<<endl;
            }
    }; //end of class Base


    class Derived: public Base
    {
        private:
            int c; 
            
        public:
            Derived()
            {
                this->c=0;
                cout<<"parameterless ctor of Derived class"<<endl;
            }
            Derived(int a, int b, int c):Base(a, b)
            {
                this->c=c;
                cout<<"parameterized ctor of Derived class"<<endl;
            }
            void print()
            {
                Base::print();
                cout<<"inside class Derived::"<<endl;
                cout<<"this->c="<<this->c<<"["<< &this->c<<"]"<<endl;
            }

            ~Derived()
            {
                this->c=0;
                cout<<"dtor of Derived class"<<endl;
            }
    }; //end of class Base
} // end of Namespace NCasting
using namespace NCasting;
int main(void)
{
     
/*Virtual functions: function which gets called depending on type of object
rather than type of pointer such type of function is called as virtual
function.*/
    Base *ptrBase= new Derived(50,60,70); // upcasting
    cout<<"ptrBase="<<endl;
    ptrBase->print();  // Derived class
    delete ptrBase;
    ptrBase=NULL;

    Base *ptrBase1= NULL;
    Derived objDerived(11,22,33);
    ptrBase1= &objDerived;   // upcasting
    cout<<"ptrBase1="<<endl;
    ptrBase1->print();  // Derived class
    ptrBase=NULL;

    return 0;
}