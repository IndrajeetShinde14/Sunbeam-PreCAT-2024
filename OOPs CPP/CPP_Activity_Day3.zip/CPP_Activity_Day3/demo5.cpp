// function overriding

#include<iostream>
using namespace std;
//abstract class
class Shape
{
    protected:
        double area;
        double perimeter;
    public:
        Shape()
        {
            this->area=0;
            this->perimeter=0;
            cout<<"inside parameterless ctor of Shpae(base) class"<<endl;
        }
        // pure virtual function
        virtual void accept_input()=0 ;
        // virtual function
        virtual void print_output()
        {
            cout<<"inside shape (base) class"<<endl;
            cout<<"this->area="<< this->area<<endl;
            cout<<"this->perimeter="<< this->perimeter<<endl;
        }
        virtual void calculate_area()
        {

        }
        virtual void calculate_perimeter()
        {

        }      

        //~Shape()
        virtual ~Shape()
        {
            this->area=0;
            this->perimeter=0;
            cout<<"inside dtor of Shpae(base) class"<<endl;
        }

};// end of shape (base) class

class Circle: public Shape
{
    private:
        double radius;
    public:
        Circle()
        {
            this->radius=0;
            cout<<"inside parameterless ctor of Circle(Derived) class"<<endl;
        }
        void accept_input()
        {
            cout<<"Enter radius=";
            cin>>this->radius;
        }
        
        /*void print_output()
        {
            cout<<"inside Circle (Derived) class"<<endl;
            cout<<"this->radius="<< this->radius<<endl;
            cout<<"this->area="<< this->area<<endl;
            cout<<"this->perimeter="<< this->perimeter<<endl;
        }*/
        void calculate_area()
        {
            this->area= 3.142* this->radius *this->radius;
        }
        void calculate_perimeter()
        {
            this->perimeter= 2 *  3.142 * this->radius;
        }      

        ~Circle()
        {
            this->area=0;
            this->perimeter=0;
            this->radius=0;
            cout<<"inside dtor of Circle(Derived) class"<<endl;
        }

};// end of circle (derived) class



class Rectangle: public Shape
{
    private:
        double l;
        double b;

    public:
        Rectangle()
        {
            this->l=0;
            this->b=0;
            cout<<"inside parameterless ctor of Rectangle(Derived) class"<<endl;
        }
        void accept_input()
        {
            cout<<"Enter l=";
            cin>>this->l;
            cout<<"Enter B=";
            cin>>this->b;
            
        }
        
        void print_output()
        {
            cout<<"inside Rectangle (Derived) class"<<endl;
            cout<<"this->l="<< this->l<<endl;
            cout<<"this->b="<< this->b<<endl;
            cout<<"this->area="<< this->area<<endl;
            cout<<"this->perimeter="<< this->perimeter<<endl;
        }
        void calculate_area()
        {
            this->area= this->l *this->b;
        }
        void calculate_perimeter()
        {
            this->perimeter= 2 * (this->l + this->b);
        }      

        ~Rectangle()
        {
            this->area=0;
            this->perimeter=0;
            this->l=0;
            this->b=0;
            cout<<"inside dtor of Rectangle(Derived) class"<<endl;
        }

};// end of Rectangle (derived) class

int menu_choice()
{
    int choice;
    cout<<"\n 1. Circle \n 2. Rectangle \n 0. Exit";
    cout<<"Enter choice=";
    cin>>choice;
    return choice;
}
int main(void)
{
    //Shape ObjShape; // error as shape is abstract class
    //object of abstract class type "Shape" is not allowed:C/C++(322)

    Shape *ptrShape=NULL; // pointer is of base class

    int choice;
    do 
    {
        choice=menu_choice();
        switch(choice)
        {
            default : cout<<" invalid case "<<endl;
                    continue;
            case 0: 
                        return 0; // exit(0)  stdlib.h or cstdlib
            case 1: // circle
                    ptrShape= new Circle; // upcasting
                    break;
            case 2: // Rectangle
                    ptrShape= new Rectangle; // upcasting
                    break;
        }
        if( ptrShape!=NULL)
        {
            ptrShape->accept_input();
            ptrShape->calculate_area();
            ptrShape->calculate_perimeter();
            ptrShape->print_output();

            delete ptrShape;
            ptrShape=NULL;
        }
        cout<<"Enter 1 to continue or 0 to exit :: ";
        cin>>choice;

    }while (choice!=0);
    return 0;   
}