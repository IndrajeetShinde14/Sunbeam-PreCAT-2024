#include<iostream>
using namespace std;
namespace NCasting
{
    class Base
    {
        private:
            int a; 
            int b;
        public:
            Base()
            {
                this->a=0;
                this->b=0;
                cout<<"parameterless ctor of base class"<<endl;
            }
            Base(int a, int b)
            {
                this->a=a;
                this->b=b;
                cout<<"parameterized ctor of base class"<<endl;
            }
            void print()
            {
                cout<<"inside class Base"<<endl;
                cout<<"this->a="<<this->a<<"["<< &this->a<<"]"<<endl;
                cout<<"this->b="<<this->b<<"["<< &this->b<<"]"<<endl;
            }

            ~Base()
            {
                this->a=0;
                this->b=0;
                cout<<"dtor of base class"<<endl;
            }
    }; //end of class Base


    class Derived: public Base
    {
        private:
            int c; 
            
        public:
            Derived()
            {
                this->c=0;
                cout<<"parameterless ctor of Derived class"<<endl;
            }
            Derived(int a, int b, int c):Base(a, b)
            {
                this->c=c;
                cout<<"parameterized ctor of Derived class"<<endl;
            }
            void print()
            {
                Base::print();
                cout<<"inside class Derived::"<<endl;
                cout<<"this->c="<<this->c<<"["<< &this->c<<"]"<<endl;
            }

            ~Derived()
            {
                this->c=0;
                cout<<"dtor of Derived class"<<endl;
            }
    }; //end of class Base
} // end of Namespace NCasting
using namespace NCasting;
int main(void)
{
     //Down casting : storing address of base class object  into derived 
//class pointer is called as downcasting. 

    //Derived *ptrDerived= new Base; // down casting
    
    Derived *ptrDerived1= NULL;
    Base objBase;
    //ptrDerived1= &objBase;   // dwon casting
    

    //Derived *ptrDerived2= new Base; // down casting
    
    return 0;
}