/*

upcasting down casting
object slicing
virtual function
function overriding



    Up casting : Storing address of  derived class object into base class 
pointer. Such concept is called as up casting. 

Down casting : storing address of base class object  into derived 
class pointer is called as downcasting. 


    Object slicing : when we assign derived class object to the
base class object at that time base class portion which is
available in derived class object is assign to the base class
object. Such slicing (cutting) of base class portion from
derived class object is called object slicing.


    Virtual functions: function which gets called depending on type of object
rather than type of pointer such type of function is called as virtual
function.

    Class which contains at least one virtual function such type of class is
called as polymorphic class. This is late binding.

Late Binding :
    When call to the virtual function is given by either by using pointer
or reference the it is late binding. In rest of the cases it is Early binding


static data member and fucntion
diamond pro sol no2 diagram

ctor
namespace
reference
casting oeprator

*/