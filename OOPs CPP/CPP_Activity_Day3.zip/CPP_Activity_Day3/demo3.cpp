#include<iostream>
using namespace std;
namespace NObjectSlicing
{
    class Base
    {
        private:
            int a; 
            int b;
        public:
            Base()
            {
                this->a=0;
                this->b=0;
                cout<<"parameterless ctor of base class"<<endl;
            }
            Base(int a, int b)
            {
                this->a=a;
                this->b=b;
                cout<<"parameterized ctor of base class"<<endl;
            }
            void print()
            {
                cout<<"inside class Base"<<endl;
                cout<<"this->a="<<this->a<<"["<< &this->a<<"]"<<endl;
                cout<<"this->b="<<this->b<<"["<< &this->b<<"]"<<endl;
            }

            ~Base()
            {
                this->a=0;
                this->b=0;
                cout<<"dtor of base class"<<endl;
            }
    }; //end of class Base


    class Derived: public Base
    {
        private:
            int c; 
            
        public:
            Derived()
            {
                this->c=0;
                cout<<"parameterless ctor of Derived class"<<endl;
            }
            Derived(int a, int b, int c):Base(a, b)
            {
                this->c=c;
                cout<<"parameterized ctor of Derived class"<<endl;
            }
            void print()
            {
                Base::print();
                cout<<"inside class Derived::"<<endl;
                cout<<"this->c="<<this->c<<"["<< &this->c<<"]"<<endl;
            }

            ~Derived()
            {
                this->c=0;
                cout<<"dtor of Derived class"<<endl;
            }
    }; //end of class Base
} // end of Namespace NObjectSlicing
using namespace NObjectSlicing;
int main(void)
{
    Base objBase;  // parameterless ctor
    cout<<"objBase="<<endl;
    objBase.print(); // a=0  b=0

    Derived  objDerived(50,60,70);
    cout<<"objDerived="<<endl;
    objDerived.print(); // a=50 b=60, c=70

/*Object slicing : when we assign derived class object to the
base class object at that time base class portion which is
available in derived class object is assign to the base class
object. Such slicing (cutting) of base class portion from
derived class object is called object slicing.
*/
 //  a, b
    objBase= objDerived;  // object slicing
              //a,b, c
    cout<<"objBase="<<endl;
    objBase.print(); // a=50  b=60

   // a,b,c
    //objDerived= objBase;   // error
            /// a,b
    //error: no match for ‘operator=’ (operand types are ‘NObjectSlicing::Derived’ and ‘NObjectSlicing::Base’)

    

    return 0;
}