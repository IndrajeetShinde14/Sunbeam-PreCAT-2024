// template can be used for 1. functions 2. class
#include<iostream>
using namespace std;
namespace NSWAP
{  // 1 int 2. float 3. char
    template <class Type>
    void  swap(Type &n1, Type &n2)
    {
        cout<<"inside my swap func"<<endl;
        Type temp;
        temp=n1;
        n1=n2;
        n2=temp;
    }
}
int main(void)
{
    {
        cout<<"for int data type"<<endl;

        int no1=100, no2=200;
        cout<<"before swap in main no1="<<no1<<" \t no2="<<no2<<endl;
        NSWAP::swap(no1, no2); // my swap
        cout<<"after swap in main no1="<<no1<<" \t no2="<<no2<<endl;

        cout <<"============================="<<endl;
    }
    {
        cout<<"for float data type"<<endl;
        float no1=10.2f, no2=20.1F;
        cout<<"before swap in main no1="<<no1<<" \t no2="<<no2<<endl;
        NSWAP::swap(no1, no2); // my swap
        cout<<"after swap in main no1="<<no1<<" \t no2="<<no2<<endl;

        cout<<"============================="<<endl;
    }
    
    {
        cout<<"for char data type"<<endl;

        char  no1='A', no2='B';
        cout<<"before swap in main no1="<<no1<<" \t no2="<<no2<<endl;
        NSWAP::swap(no1, no2); // my swap
        cout<<"after swap in main no1="<<no1<<" \t no2="<<no2<<endl;

        cout <<"============================="<<endl;
    }

    float n1=2.3f, n2=3.2f;
    cout<<"before swap in main n1="<<n1<<" \t n2="<<n2<<endl;
    swap(n1, n2);  // stl swap
    cout<<"after swap in main n1="<<n1<<" \t n2="<<n2<<endl;

    return 0;
}

